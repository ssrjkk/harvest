"""HARVEST BOT FORGE — автономный бот-пульт (24/7 в облаке, без ПК).

Читает state.json с GitHub Pages (метрики фермы, которые публикует
publish_dash.py с твоего ПК). Работает даже когда ПК выключен:
показывает последнее состояние фермы.

Переменные окружения:
  BOT_TOKEN   — токен от @BotFather (обязательно)
  STATE_URL   — URL state.json (по умолчанию https://ssrjkk.github.io/harvest/state.json)
"""

import json
import os
import urllib.request

from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart
from aiogram.types import Message

TOKEN = os.environ["BOT_TOKEN"]
STATE_URL = os.environ.get(
    "STATE_URL", "https://ssrjkk.github.io/harvest/state.json"
)
AUTHOR = "👤 Автор: <a href='https://t.me/ssrjkk_bot'>@ssrjkk_bot</a>"


def esc(v):
    return str(v or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def fetch_state():
    req = urllib.request.Request(STATE_URL)
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode())


def fmt_status(s):
    pool = s.get("pool", {})
    db = s.get("db", {})
    state = "▶ работает" if s.get("running") else "⏹ остановлена"
    if pool.get("paused"):
        state += " ⏸"
    return (
        "📊 <b>HARVEST — статус</b>\n\n"
        f"Ферма: <b>{state}</b>\n"
        f"• Действий: <b>{pool.get('actions', 0)}</b> · ошибок: <b>{pool.get('errors', 0)}</b>\n"
        f"• Обработано: <b>{pool.get('processed', 0)}</b> · циклов: <b>{pool.get('cycles', 0)}</b>\n"
        f"• Кошельков: <b>{s.get('wallet_count', '-')}</b>\n"
        f"• Health: <b>{s.get('health_factor', 1.0):.2f}</b>\n"
        f"• Обновлено: <b>{esc(s.get('updated_at', '-'))}</b>\n\n"
        f"⚠️ Если данные старые — ПК с фермой выключен.\n\n"
        f"{AUTHOR}"
    )


async def main():
    bot = Bot(token=TOKEN, default={"parse_mode": ParseMode.HTML})
    dp = Dispatcher()

    @dp.message(CommandStart())
    async def on_start(m: Message) -> None:
        await m.answer(
            "Привет! Это <b>HARVEST</b> — пульт фермы.\n"
            "• /status — текущее состояние\n"
            "• /help — справка\n\n"
            + AUTHOR,
            parse_mode=ParseMode.HTML,
        )

    @dp.message()
    async def on_msg(m: Message) -> None:
        text = (m.text or "").strip()
        if text == "/status":
            try:
                await m.answer(fmt_status(fetch_state()), parse_mode=ParseMode.HTML)
            except Exception:  # noqa: BLE001
                await m.answer("⚠️ Не удалось получить состояние фермы.", parse_mode=ParseMode.HTML)
        elif text == "/help":
            await m.answer(
                "Возможности:\n• /status — состояние фермы\n• /start — меню\n\n" + AUTHOR,
                parse_mode=ParseMode.HTML,
            )

    print("HARVEST BotForge started, polling...")
    await dp.start_polling(bot)


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())